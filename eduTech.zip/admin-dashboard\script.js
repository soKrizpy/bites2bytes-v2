// File: admin-dashboard/script.js

document.addEventListener('DOMContentLoaded', () => {
    // ---- Perbarui UI Profil Secara Dinamis ---- //
    if (window.updateProfileUI) window.updateProfileUI();

    // ---- Logic Tab Navigasi Sidebar ---- //
    const navItems = document.querySelectorAll('.nav-item');
    const tabPanes = document.querySelectorAll('.tab-pane');
    const sidebar = document.querySelector('.sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');

    const closeMobileSidebar = () => {
        if (window.innerWidth <= 768) {
            sidebar.classList.remove('open');
            sidebarOverlay.classList.add('hidden');
        }
    };

    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => {
            sidebar.classList.add('open');
            sidebarOverlay.classList.remove('hidden');
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', closeMobileSidebar);
    }

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(nav => nav.classList.remove('active'));
            tabPanes.forEach(pane => {
                pane.classList.remove('active');
                pane.classList.add('hidden');
            });

            item.classList.add('active');
            const targetId = item.getAttribute('data-target');
            const targetPane = document.getElementById(targetId);
            
            if(targetPane) {
                targetPane.classList.remove('hidden');
                targetPane.classList.add('active');
                
                // Trigger refresh data if needed
                if (targetId === 'users-management-tab') {
                    renderUserTable('student', 'students-table-body');
                    renderUserTable('teacher', 'teachers-table-body');
                    renderEnrollmentTable();
                } else if (targetId === 'curriculum-tab') {
                    renderCurriculum();
                } else if (targetId === 'finance-tab') {
                    renderFinanceTab();
                }
            }

            // Close sidebar on mobile after selection
            closeMobileSidebar();
        });
    });

    // ---- Logic Toggle MPIN (Global Function) ---- //
    window.toggleMPIN = (id) => {
        const mpinInput = document.getElementById(`mpin-${id}`);
        const btn = mpinInput.nextElementSibling;
        
        if (mpinInput.type === 'password') {
            mpinInput.type = 'text';
            btn.textContent = '🔒';
            btn.setAttribute('title', 'Sembunyikan MPIN');
        } else {
            mpinInput.type = 'password';
            btn.textContent = '👁️';
            btn.setAttribute('title', 'Tampilkan MPIN');
        }
    };

    // ======================================================
    // STAT CARDS LIVE — Hubungkan ke LocalStorage
    // ======================================================
    function updateDashboardStats() {
        const users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
        const enrollments = JSON.parse(localStorage.getItem('b2b_enrollments') || '[]');

        const students = users.filter(u => u.role === 'student');
        const teachers = users.filter(u => u.role === 'teacher');
        const activeEnrollments = enrollments.filter(e => e.status === 'active');

        const total = students.length + teachers.length;

        const statTotal = document.getElementById('stat-total');
        const statStudents = document.getElementById('stat-students');
        const statTeachers = document.getElementById('stat-teachers');
        const statEnrollments = document.getElementById('stat-enrollments');
        const statNewThisMonth = document.getElementById('stat-new-this-month');

        if (statTotal) {
            animateCount(statTotal, total, 1000, 0);
        }
        if (statNewThisMonth) {
            statNewThisMonth.textContent = `+${enrollments.length} enrollment aktif`;
        }
        if (statStudents) animateCount(statStudents, students.length);
        if (statTeachers) animateCount(statTeachers, teachers.length);
        if (statEnrollments) animateCount(statEnrollments, activeEnrollments.length);
    }

    updateDashboardStats();

    // ======================================================
    // LEADERBOARD & TEACHER PERFORMANCE (IKHTISAR SISTEM)
    // ======================================================
    function renderAdminLeaderboard() {
        const users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
        const globalProgress = JSON.parse(localStorage.getItem('b2b_progress') || '{}');
        const students = users.filter(u => u.role === 'student');
        
        const leaderboardData = students.map(st => {
            const prog = globalProgress[st.id] || { xp: 0, completedTopics: [] };
            return {
                id: st.id,
                name: st.name || st.id,
                xp: prog.xp || 0,
                topics: (prog.completedTopics || []).length
            };
        });

        leaderboardData.sort((a, b) => b.xp - a.xp);
        const top5 = leaderboardData.slice(0, 5);

        const tbody = document.getElementById('admin-leaderboard-body');
        if (!tbody) return;

        if (top5.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">Belum ada data siswa.</td></tr>';
            return;
        }

        tbody.innerHTML = top5.map((st, idx) => `
            <tr>
                <td style="text-align:center">
                    ${idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : idx + 1}
                </td>
                <td class="fw-bold">${st.name}</td>
                <td style="color:var(--primary-color); font-weight:bold">${st.xp} XP</td>
                <td>${st.topics} Topik</td>
            </tr>
        `).join('');
    }

    function renderAdminTeacherPerformance() {
        const users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
        const sessions = JSON.parse(localStorage.getItem('b2b_sessions') || '[]');
        const teachers = users.filter(u => u.role === 'teacher');

        const performanceData = teachers.map(tc => {
            const mySessions = sessions.filter(s => s.teacherId === tc.id);
            const scoredSessions = mySessions.filter(s => s.score !== null);
            let avgScore = 0;
            if (scoredSessions.length > 0) {
                avgScore = Math.round(scoredSessions.reduce((sum, s) => sum + s.score, 0) / scoredSessions.length);
            }
            return {
                id: tc.id,
                name: tc.name || tc.id,
                sessionsLogged: mySessions.length,
                avgScore: avgScore
            };
        });

        performanceData.sort((a, b) => b.sessionsLogged - a.sessionsLogged);
        const top5 = performanceData.slice(0, 5);

        const tbody = document.getElementById('admin-teacher-performance-body');
        if (!tbody) return;

        if (top5.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">Belum ada data guru.</td></tr>';
            return;
        }

        tbody.innerHTML = top5.map(tc => `
            <tr>
                <td class="fw-bold">${tc.name}</td>
                <td>${tc.sessionsLogged} Sesi</td>
                <td style="color:${tc.avgScore >= 80 ? 'var(--success-color)' : 'var(--text-muted)'}; font-weight:bold">
                    ${tc.avgScore > 0 ? tc.avgScore + '/100' : '-'}
                </td>
            </tr>
        `).join('');
    }

    renderAdminLeaderboard();
    renderAdminTeacherPerformance();

    // ======================================================
    // TABEL SISWA & GURU
    // ======================================================
    // Initial render
    renderUserTable('student', 'students-table-body');
    renderUserTable('teacher', 'teachers-table-body');

    // ======================================================
    // SISTEM BROADCAST
    // ======================================================
    const broadcastInput = document.getElementById('broadcast-message');
    const broadcastImage = document.getElementById('broadcast-image');
    const sendBroadcastBtn = document.getElementById('send-broadcast-btn');

    if (sendBroadcastBtn) {
        sendBroadcastBtn.addEventListener('click', () => {
            const msg = broadcastInput.value.trim();
            const img = broadcastImage.value.trim();
            const targetEl = document.getElementById('broadcast-target');
            const targetVal = targetEl ? targetEl.value : 'all';

            if (!msg) {
                showToast("Pesan tidak boleh kosong!", "error");
                return;
            }

            const broadcastData = {
                id: Date.now(),
                message: msg,
                imageUrl: img || null,
                sender: "Admin",
                target: targetVal,
                timestamp: new Date().toISOString()
            };

            localStorage.setItem('b2b_broadcast', JSON.stringify(broadcastData));
            
            // Trigger checkBroadcast locally since storage event doesn't fire in the same window
            if (window.checkBroadcast) {
                window.checkBroadcast();
            }
            
            showToast("Banner pengumuman berhasil dikirim!", "success");
            broadcastInput.value = '';
            broadcastImage.value = '';
        });
    }

    // ======================================================
    // MODAL & CRUD
    // ======================================================
    window.openModal = (id) => {
        document.getElementById(id).classList.remove('hidden');
        // Reset titles/buttons if they were in edit mode
        if (id === 'user-modal') {
            document.getElementById('user-modal-title').textContent = 'Tambah Pengguna Baru 👥';
            document.getElementById('user-modal-submit').textContent = 'Simpan Pengguna';
            document.getElementById('edit-user-original-id').value = '';
            document.getElementById('add-user-form').reset();
        }
        if (id === 'module-modal') {
            document.getElementById('module-modal-title').textContent = 'Buat Modul Baru 📚';
            document.getElementById('module-modal-submit').textContent = 'Terbitkan Modul';
            document.getElementById('edit-module-id').value = '';
            document.getElementById('add-module-form').reset();
        }
        // Populate dropdown enrollment modal jika yang dibuka adalah enrollment-modal
        if (id === 'enrollment-modal') populateEnrollmentDropdowns();
    };
    window.closeModal = (id) => document.getElementById(id).classList.add('hidden');

    const addUserForm = document.getElementById('add-user-form');
    if (addUserForm) {
        addUserForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const originalId = document.getElementById('edit-user-original-id').value;
            const id = document.getElementById('new-user-id').value;
            const name = document.getElementById('new-user-name').value;
            const role = document.getElementById('new-user-role').value;
            const mpin = document.getElementById('new-user-mpin').value;

            let users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
            
            if (originalId) {
                // EDIT MODE
                const idx = users.findIndex(u => u.id === originalId);
                if (idx !== -1) {
                    users[idx] = { ...users[idx], id, name, role, mpin };
                    localStorage.setItem('b2b_users', JSON.stringify(users));
                    showToast(`Data ${name} berhasil diperbarui!`, 'success');
                }
            } else {
                // ADD MODE
                if (users.find(u => u.id === id)) {
                    showToast("ID / Nomor WA sudah terdaftar!", "error");
                    return;
                }

                users.push({
                    id: id,
                    name: name,
                    role: role,
                    extra: role === 'student' ? 'Basic' : 'Instruktur',
                    mpin: mpin,
                    ...(role === 'teacher' && { honorarium: 75000, sessionsCompleted: 0 })
                });
                localStorage.setItem('b2b_users', JSON.stringify(users));
                showToast(`Pengguna ${name} berhasil ditambahkan!`, 'success');
            }

            closeModal('user-modal');
            addUserForm.reset();
            
            renderUserTable('student', 'students-table-body');
            renderUserTable('teacher', 'teachers-table-body');
            updateDashboardStats();
        });
    }

    window.editUser = (id) => {
        const users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
        const user = users.find(u => u.id === id);
        if (!user) return;

        document.getElementById('user-modal-title').textContent = 'Edit Pengguna ✏️';
        document.getElementById('user-modal-submit').textContent = 'Update Pengguna';
        document.getElementById('edit-user-original-id').value = user.id;
        
        document.getElementById('new-user-id').value = user.id;
        document.getElementById('new-user-name').value = user.name;
        document.getElementById('new-user-role').value = user.role;
        document.getElementById('new-user-mpin').value = user.mpin;

        document.getElementById('user-modal').classList.remove('hidden');
    };

    const addModuleForm = document.getElementById('add-module-form');
    if (addModuleForm) {
        addModuleForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const editId = document.getElementById('edit-module-id').value;
            const title = document.getElementById('new-module-title').value;
            const summary = document.getElementById('new-module-summary').value;
            const teacher = document.getElementById('new-module-teacher').value;

            let modules = JSON.parse(localStorage.getItem('b2b_modules') || '[]');
            
            if (editId) {
                // EDIT MODE
                const idx = modules.findIndex(m => m.id === editId);
                if (idx !== -1) {
                    modules[idx] = { ...modules[idx], title, summary, teacherId: teacher };
                    localStorage.setItem('b2b_modules', JSON.stringify(modules));
                    showToast(`Modul "${title}" diperbarui!`, 'success');
                }
            } else {
                // ADD MODE
                modules.push({
                    id: 'mod-' + Date.now(),
                    title,
                    summary,
                    teacherId: teacher,
                    topics: []
                });
                localStorage.setItem('b2b_modules', JSON.stringify(modules));
                showToast(`Modul "${title}" berhasil diterbitkan!`, 'success');
            }

            closeModal('module-modal');
            addModuleForm.reset();
            renderCurriculum();
        });
    }

    window.editModule = (id) => {
        const modules = JSON.parse(localStorage.getItem('b2b_modules') || '[]');
        const mod = modules.find(m => m.id === id);
        if (!mod) return;

        document.getElementById('module-modal-title').textContent = 'Edit Modul ✏️';
        document.getElementById('module-modal-submit').textContent = 'Update Modul';
        document.getElementById('edit-module-id').value = mod.id;
        
        document.getElementById('new-module-title').value = mod.title;
        document.getElementById('new-module-summary').value = mod.summary;
        document.getElementById('new-module-teacher').value = mod.teacherId || '';

        document.getElementById('module-modal').classList.remove('hidden');
    };

    // ======================================================
    // ENROLLMENT MANAGEMENT
    // ======================================================

    /** Populate dropdown di modal enrollment dari data LocalStorage */
    function populateEnrollmentDropdowns() {
        const users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
        const modules = JSON.parse(localStorage.getItem('b2b_modules') || '[]');

        const studentSel = document.getElementById('enr-student');
        const teacherSel = document.getElementById('enr-teacher');
        const moduleSel = document.getElementById('enr-module');

        if (!studentSel || !teacherSel || !moduleSel) return;

        // Siswa
        studentSel.innerHTML = '<option value="">-- Pilih Siswa --</option>';
        users.filter(u => u.role === 'student').forEach(u => {
            studentSel.innerHTML += `<option value="${u.id}" data-name="${u.name}">${u.name} (${u.id})</option>`;
        });

        // Guru
        teacherSel.innerHTML = '<option value="">-- Pilih Guru --</option>';
        users.filter(u => u.role === 'teacher').forEach(u => {
            teacherSel.innerHTML += `<option value="${u.id}" data-name="${u.name}">${u.name}</option>`;
        });

        // Modul
        moduleSel.innerHTML = '<option value="">-- Pilih Modul --</option>';
        modules.forEach(m => {
            moduleSel.innerHTML += `<option value="${m.id}" data-name="${m.title}">${m.title}</option>`;
        });
    }

    /** Render tabel enrollment */
    function renderEnrollmentTable() {
        const tbody = document.getElementById('enrollment-table-body');
        if (!tbody) return;

        const enrollments = JSON.parse(localStorage.getItem('b2b_enrollments') || '[]');

        if (enrollments.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted p-20">Belum ada enrollment. Silakan assign siswa ke guru.</td></tr>';
            return;
        }

        tbody.innerHTML = enrollments.map(enr => `
            <tr class="fade-in">
                <td>
                    <div class="flex items-center gap-2">
                        <div class="avatar" style="width:30px; height:30px; font-size:10px; background:var(--primary-color)">${enr.studentName ? enr.studentName.charAt(0) : '?'}</div>
                        <div>
                            <div class="fw-bold text-sm">${enr.studentName}</div>
                            <div class="text-xs text-muted">${enr.studentId}</div>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="fw-bold text-sm">${enr.teacherName}</div>
                    <div class="text-xs text-muted">${enr.teacherId}</div>
                </td>
                <td><span class="badge badge-primary">${enr.moduleName}</span></td>
                <td class="text-xs text-muted">${formatDate(enr.enrolledAt)}</td>
                <td><span class="badge ${enr.status === 'active' ? 'badge-success' : 'badge-warning'}">${enr.status === 'active' ? '✅ Aktif' : '⏸ Nonaktif'}</span></td>
                <td>
                    <button class="icon-btn-sm text-warning" title="Nonaktifkan" onclick="toggleEnrollmentStatus('${enr.id}')">⏸</button>
                    <button class="icon-btn-sm text-danger" title="Hapus" onclick="deleteEnrollment('${enr.id}')">🗑️</button>
                </td>
            </tr>
        `).join('');
    }

    /** Form submit: tambah enrollment baru */
    const enrollmentForm = document.getElementById('enrollment-form');
    if (enrollmentForm) {
        enrollmentForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const studentSel = document.getElementById('enr-student');
            const teacherSel = document.getElementById('enr-teacher');
            const moduleSel = document.getElementById('enr-module');

            const studentId = studentSel.value;
            const studentName = studentSel.options[studentSel.selectedIndex].getAttribute('data-name');
            const teacherId = teacherSel.value;
            const teacherName = teacherSel.options[teacherSel.selectedIndex].getAttribute('data-name');
            const moduleId = moduleSel.value;
            const moduleName = moduleSel.options[moduleSel.selectedIndex].getAttribute('data-name');

            if (!studentId || !teacherId || !moduleId) {
                showToast("Lengkapi semua pilihan!", "error");
                return;
            }

            const enrollments = JSON.parse(localStorage.getItem('b2b_enrollments') || '[]');

            // Cegah duplikasi enrollment (siswa + modul yang sama)
            const duplicate = enrollments.find(e => e.studentId === studentId && e.moduleId === moduleId);
            if (duplicate) {
                showToast("Siswa ini sudah terdaftar di modul tersebut!", "error");
                return;
            }

            const newEnrollment = {
                id: 'enr-' + Date.now(),
                studentId,
                studentName,
                teacherId,
                teacherName,
                moduleId,
                moduleName,
                enrolledAt: new Date().toISOString().split('T')[0],
                status: 'active'
            };

            enrollments.push(newEnrollment);
            localStorage.setItem('b2b_enrollments', JSON.stringify(enrollments));

            showToast(`${studentName} berhasil di-assign ke ${teacherName}!`, 'success');
            closeModal('enrollment-modal');
            enrollmentForm.reset();
            renderEnrollmentTable();
            updateDashboardStats();
        });
    }

    /** Toggle status enrollment aktif/nonaktif */
    window.toggleEnrollmentStatus = (id) => {
        const enrollments = JSON.parse(localStorage.getItem('b2b_enrollments') || '[]');
        const idx = enrollments.findIndex(e => e.id === id);
        if (idx !== -1) {
            enrollments[idx].status = enrollments[idx].status === 'active' ? 'inactive' : 'active';
            localStorage.setItem('b2b_enrollments', JSON.stringify(enrollments));
            showToast("Status enrollment diperbarui.", "success");
            renderEnrollmentTable();
            updateDashboardStats();
        }
    };

    /** Hapus enrollment */
    window.deleteEnrollment = (id) => {
        if (confirm('Hapus enrollment ini? Siswa tidak akan lagi terassign ke guru tersebut.')) {
            let enrollments = JSON.parse(localStorage.getItem('b2b_enrollments') || '[]');
            enrollments = enrollments.filter(e => e.id !== id);
            localStorage.setItem('b2b_enrollments', JSON.stringify(enrollments));
            showToast("Enrollment berhasil dihapus.", "success");
            renderEnrollmentTable();
            updateDashboardStats();
        }
    };

    // ======================================================
    // FINANCE TAB — Honorarium & Session Log
    // ======================================================
    function renderFinanceTab() {
        const sessions = JSON.parse(localStorage.getItem('b2b_sessions') || '[]');
        const users = JSON.parse(localStorage.getItem('b2b_users') || '[]');

        // --- Hitung Statistik Keseluruhan ---
        const totalSessions = sessions.length;
        const hadirSessions = sessions.filter(s => s.attendance === 'hadir');
        const attendanceRate = totalSessions > 0 ? Math.round((hadirSessions.length / totalSessions) * 100) : 0;
        const totalHonorarium = hadirSessions.reduce((sum, s) => sum + (s.honorariumPerSesi || 0), 0);
        const teachers = users.filter(u => u.role === 'teacher');
        const avgHonorarium = teachers.length > 0 ? Math.round(totalHonorarium / teachers.length) : 0;

        // Update stat cards
        const elTotal = document.getElementById('finance-total-honorarium');
        const elSessions = document.getElementById('finance-total-sessions');
        const elAvg = document.getElementById('finance-avg-honorarium');
        const elRate = document.getElementById('finance-attendance-rate');

        if (elTotal) elTotal.textContent = formatRupiah(totalHonorarium);
        if (elSessions) elSessions.textContent = `${hadirSessions.length} sesi hadir dari ${totalSessions} total`;
        if (elAvg) elAvg.textContent = formatRupiah(avgHonorarium);
        if (elRate) elRate.textContent = `${attendanceRate}%`;

        // --- Payroll per Guru ---
        const payrollBody = document.getElementById('finance-payroll-body');
        if (payrollBody) {
            if (teachers.length === 0) {
                payrollBody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Belum ada data guru.</td></tr>';
            } else {
                payrollBody.innerHTML = teachers.map(teacher => {
                    const teacherSessions = sessions.filter(s => s.teacherId === teacher.id);
                    const hadirCount = teacherSessions.filter(s => s.attendance === 'hadir').length;
                    const honorPerSesi = teacherSessions[0]?.honorariumPerSesi || 75000;
                    const totalEarned = hadirCount * honorPerSesi;

                    return `
                        <tr class="fade-in">
                            <td>
                                <div class="flex items-center gap-2">
                                    <div class="avatar" style="width:30px; height:30px; font-size:10px; background:var(--success-color)">${teacher.name.charAt(0)}</div>
                                    <span class="fw-bold">${teacher.name}</span>
                                </div>
                            </td>
                            <td class="text-center">${teacherSessions.length}</td>
                            <td class="text-center">${hadirCount}</td>
                            <td>${formatRupiah(honorPerSesi)}</td>
                            <td class="fw-bold text-success">${formatRupiah(totalEarned)}</td>
                            <td><span class="badge badge-success">✅ Aktif</span></td>
                        </tr>
                    `;
                }).join('');
            }
        }

        // --- Log Sesi ---
        const sessionsBody = document.getElementById('finance-sessions-body');
        if (sessionsBody) {
            if (sessions.length === 0) {
                sessionsBody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Belum ada sesi tercatat.</td></tr>';
            } else {
                // Urutkan dari terbaru
                const sorted = [...sessions].sort((a, b) => new Date(b.date) - new Date(a.date));
                sessionsBody.innerHTML = sorted.map(ses => `
                    <tr class="fade-in">
                        <td class="text-xs text-muted">${formatDate(ses.date)}</td>
                        <td class="fw-bold text-sm">${ses.studentName}</td>
                        <td class="text-sm">${ses.teacherName}</td>
                        <td class="text-xs text-muted">${ses.topic}</td>
                        <td>
                            <span class="badge ${ses.attendance === 'hadir' ? 'badge-success' : 'badge-danger'}">
                                ${ses.attendance === 'hadir' ? '✅ Hadir' : '❌ Absen'}
                            </span>
                        </td>
                        <td class="fw-bold">${ses.score !== null ? ses.score + '/100' : '<span class="text-muted">-</span>'}</td>
                    </tr>
                `).join('');
            }
        }
    }

    // ======================================================
    // KURIKULUM
    // ======================================================
    const modulesList = document.getElementById('modules-list');

    function renderCurriculum() {
        const modules = JSON.parse(localStorage.getItem('b2b_modules') || '[]');
        if (!modulesList) return;

        if (modules.length === 0) {
            modulesList.innerHTML = '<div class="text-center p-8 text-muted">Belum ada modul. Silakan buat modul baru.</div>';
            return;
        }

        modulesList.innerHTML = modules.map(mod => `
            <div class="bento-box glass mb-15">
                <div class="flex-between">
                    <div>
                        <h3 class="fw-bold">${mod.title}</h3>
                        <p class="text-xs text-muted">${mod.topics.length} Topik | ID: ${mod.id}</p>
                    </div>
                    <div class="flex gap-2">
                        <button class="btn btn-sm btn-outline" onclick="editModule('${mod.id}')">Edit</button>
                        <button class="btn btn-sm btn-outline text-danger" style="color: var(--danger-color);" onclick="deleteModule('${mod.id}')">Hapus</button>
                    </div>
                </div>
                <div class="mt-15 p-10 bg-darker rounded text-sm">
                    <strong>Ringkasan:</strong> ${mod.summary}
                </div>
            </div>
        `).join('');
    }

    window.deleteModule = (id) => {
        if (confirm('Apakah Anda yakin ingin menghapus modul ini? Seluruh enrollment terkait mungkin akan bermasalah.')) {
            let modules = JSON.parse(localStorage.getItem('b2b_modules') || '[]');
            modules = modules.filter(m => m.id !== id);
            localStorage.setItem('b2b_modules', JSON.stringify(modules));
            showToast("Modul berhasil dihapus.", "success");
            renderCurriculum();
        }
    };

    // ======================================================
    // MANAJEMEN USER
    // ======================================================
    function renderUserTable(role, tbodyId) {
        const tbody = document.getElementById(tbodyId);
        if (!tbody) return;

        const allUsers = JSON.parse(localStorage.getItem('b2b_users') || '[]');
        const filtered = allUsers.filter(u => u.role === role);

        if (filtered.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted p-20">Belum ada data ${role === 'student' ? 'siswa' : 'guru'}.</td></tr>`;
            return;
        }

        tbody.innerHTML = filtered.map(user => `
            <tr class="fade-in">
                <td><input type="checkbox" class="user-checkbox" data-id="${user.id}" data-role="${user.role}" onchange="updateBulkActionBar()"></td>
                <td class="font-mono text-xs">${user.id}</td>
                <td><div class="flex items-center gap-2"><div class="avatar" style="width:30px; height:30px; font-size:10px; background:var(--primary-color)">${user.name ? user.name.charAt(0) : '?'}</div><span class="fw-bold">${user.name || 'User Baru'}</span></div></td>
                <td><span class="badge ${user.role === 'student' ? 'badge-primary' : 'badge-success'}">${user.extra || (user.role === 'student' ? 'Basic' : 'Instruktur')}</span></td>
                <td>
                    <div class="mpin-container">
                        <input type="password" value="${user.mpin}" class="mpin-input" id="mpin-${user.id}">
                        <button class="icon-btn-sm" onclick="toggleMPIN('${user.id}')">👁️</button>
                    </div>
                </td>
                <td>
                    <button class="icon-btn-sm text-info" onclick="editUser('${user.id}')">✏️</button>
                    <button class="icon-btn-sm text-danger" onclick="deleteUser('${user.id}')">🗑️</button>
                </td>
            </tr>
        `).join('');
    }

    window.deleteUser = (id) => {
        if(confirm('Hapus pengguna ini? Seluruh enrollment terkait akan tetap ada.')) {
            let users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
            users = users.filter(u => u.id !== id);
            localStorage.setItem('b2b_users', JSON.stringify(users));
            showToast("Pengguna berhasil dihapus", "success");
            renderUserTable('student', 'students-table-body');
            renderUserTable('teacher', 'teachers-table-body');
            updateDashboardStats();
        }
    };

    // ======================================================
    // EVENT: Tab Click Handlers
    // ======================================================
    document.querySelector('[data-target="users-management-tab"]')?.addEventListener('click', () => {
        // Data refreshed in tab click handler above
    });
    document.querySelector('[data-target="curriculum-tab"]')?.addEventListener('click', () => {
        // Data refreshed in tab click handler above
    });
    document.querySelector('[data-target="finance-tab"]')?.addEventListener('click', () => {
        // Data refreshed in tab click handler above
    });

    // ---- Logic Sub-Tabs Manajemen Pengguna ---- //
    const subTabBtns = document.querySelectorAll('.sub-tab-btn');
    const subTabPanes = document.querySelectorAll('.sub-tab-pane');

    subTabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            subTabBtns.forEach(b => {
                b.classList.remove('active', 'btn-primary');
                b.classList.add('btn-outline');
            });
            
            subTabPanes.forEach(pane => {
                pane.classList.remove('active');
                pane.classList.add('hidden');
            });

            btn.classList.add('active', 'btn-primary');
            btn.classList.remove('btn-outline');
            
            const targetId = btn.getAttribute('data-subtarget');
            const targetPane = document.getElementById(targetId);
            if(targetPane) {
                targetPane.classList.remove('hidden');
                targetPane.classList.add('active');
            }
        });
    });

    // ======================================================
    // LIVE SEARCH
    // ======================================================
    function setupSearch(inputId, tbodyId) {
        const input = document.getElementById(inputId);
        if (input) {
            input.addEventListener('input', (e) => {
                const term = e.target.value.toLowerCase();
                const rows = document.querySelectorAll(`#${tbodyId} tr`);
                rows.forEach(row => {
                    row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none';
                });
            });
        }
    }

    setupSearch('search-students', 'students-table-body');
    setupSearch('search-teachers', 'teachers-table-body');

    // ======================================================
    // HELPER UTILITIES
    // ======================================================
    function formatDate(dateStr) {
        if (!dateStr) return '-';
        const opts = { day: 'numeric', month: 'short', year: 'numeric' };
        return new Date(dateStr).toLocaleDateString('id-ID', opts);
    }

    function formatRupiah(amount) {
        return 'Rp ' + (amount || 0).toLocaleString('id-ID');
    }

    // ======================================================
    // BULK ACTIONS LOGIC
    // ======================================================
    window.toggleSelectAll = (role) => {
        const checkAll = document.getElementById(`check-all-${role}s`);
        const checkboxes = document.querySelectorAll(`#${role}s-table-body .user-checkbox`);
        checkboxes.forEach(cb => cb.checked = checkAll.checked);
        updateBulkActionBar();
    };

    window.updateBulkActionBar = () => {
        const selected = document.querySelectorAll('.user-checkbox:checked');
        const bar = document.getElementById('bulk-action-bar');
        const count = document.getElementById('selected-count');
        
        if (selected.length > 0) {
            bar.classList.remove('hidden');
            count.textContent = `${selected.length} dipilih`;
        } else {
            bar.classList.add('hidden');
        }
    };

    window.bulkAction = (type) => {
        const selected = document.querySelectorAll('.user-checkbox:checked');
        const ids = Array.from(selected).map(cb => cb.getAttribute('data-id'));
        
        if (type === 'delete') {
            if (confirm(`Apakah Anda yakin ingin menghapus ${ids.length} pengguna terpilih? Tindakan ini tidak dapat dibatalkan.`)) {
                let users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
                users = users.filter(u => !ids.includes(u.id));
                localStorage.setItem('b2b_users', JSON.stringify(users));
                showToast(`${ids.length} pengguna berhasil dihapus.`, "success");
            }
        } else if (type === 'deactivate') {
            // Simulasi deaktifasi dengan mengubah status di extra
            let users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
            users.forEach(u => {
                if (ids.includes(u.id)) u.status = 'inactive';
            });
            localStorage.setItem('b2b_users', JSON.stringify(users));
            showToast(`${ids.length} akun dinonaktifkan.`, "success");
        }
        
        renderUserTable('student', 'students-table-body');
        renderUserTable('teacher', 'teachers-table-body');
        updateBulkActionBar();
        updateDashboardStats();
    };

    // ======================================================
    // EXPORT LOGIC
    // ======================================================
    window.exportFinance = (format) => {
        const sessions = JSON.parse(localStorage.getItem('b2b_sessions') || '[]');
        const users = JSON.parse(localStorage.getItem('b2b_users') || '[]');
        const teachers = users.filter(u => u.role === 'teacher');
        
        const payrollData = teachers.map(teacher => {
            const tSessions = sessions.filter(s => s.teacherId === teacher.id && s.attendance === 'hadir');
            const total = tSessions.length * (teacher.honorarium || 75000);
            return {
                nama: teacher.name,
                wa: teacher.id,
                totalSesi: tSessions.length,
                totalHonor: total
            };
        });

        if (format === 'json') {
            downloadJSON({ timestamp: new Date().toISOString(), payroll: payrollData }, 'rekap-keuangan-b2b.json');
            showToast("Data Keuangan berhasil di-export ke JSON.", "success");
        } else if (format === 'pdf') {
            const html = `
                <h3>Rekapitulasi Honorarium Guru</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Nama Guru</th>
                            <th>ID / WA</th>
                            <th>Total Sesi Hadir</th>
                            <th>Total Honorarium</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${payrollData.map(d => `
                            <tr>
                                <td>${d.nama}</td>
                                <td>${d.wa}</td>
                                <td>${d.totalSesi} Sesi</td>
                                <td>${formatRupiah(d.totalHonor)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
            printReport(html, "Laporan Keuangan Bites2Bytes");
        }
    };
});
