document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const usernameInput = document.getElementById('username');
    const mpinInput = document.getElementById('mpin');
    const toggleMpinBtn = document.getElementById('toggle-mpin');
    const errorAlert = document.getElementById('error-message');
    const submitBtn = loginForm.querySelector('button[type="submit"]');
    const btnText = submitBtn.querySelector('.btn-text');
    const spinner = submitBtn.querySelector('.spinner');

    // Toggle MPIN visibility
    toggleMpinBtn.addEventListener('click', () => {
        const type = mpinInput.getAttribute('type') === 'password' ? 'text' : 'password';
        mpinInput.setAttribute('type', type);
        toggleMpinBtn.textContent = type === 'password' ? '👁️' : '🙈';
    });

    /**
     * Ambil daftar user secara dinamis
     */
    function getUsers() {
        const storedUsers = JSON.parse(localStorage.getItem('b2b_users') || '[]');

        // Map b2b_users ke format login
        const dynamicUsers = storedUsers.map(u => ({
            id: u.id,
            name: u.name,
            mpin: u.mpin,
            role: u.role,
            redirectUrl: u.role === 'student'
                ? '../student-dashboard/index.html'
                : '../teacher-dashboard/index.html'
        }));

        // Admin hardcoded (karena admin pusat biasanya tidak di manage di tabel user biasa)
        const adminUser = { 
            id: 'admin', 
            name: 'Administrator', 
            mpin: '123456', 
            role: 'admin', 
            redirectUrl: '../admin-dashboard/index.html' 
        };

        return [adminUser, ...dynamicUsers];
    }

    // Handle Login Submission
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Reset Error
        errorAlert.classList.add('hidden');
        
        const username = usernameInput.value.trim();
        const mpin = mpinInput.value;

        // UI Loading State
        submitBtn.disabled = true;
        btnText.classList.add('hidden');
        spinner.classList.remove('hidden');

        // Simulasi delay jaringan
        setTimeout(() => {
            const users = getUsers();
            const user = users.find(u => u.id === username && u.mpin === mpin);

            if (user) {
                // Ambil data lengkap dari b2b_users untuk sesi ini (termasuk bio, photoUrl, extra, dll)
                const storedUsers = JSON.parse(localStorage.getItem('b2b_users') || '[]');
                const fullUserData = storedUsers.find(u => u.id === user.id) || user;

                // Simpan sesi ke LocalStorage
                localStorage.setItem('b2b_currentUser', JSON.stringify({
                    ...fullUserData,
                    loginTime: new Date().toISOString()
                }));
                
                // Tampilkan pesan sukses via toast (dari notifications.js)
                if (window.showToast) {
                    showToast(`Selamat datang kembali, ${user.name || user.id}!`, 'success');
                }
                
                // Transisi Skeleton Loading
                setTimeout(() => {
                    const overlay = document.createElement('div');
                    overlay.className = 'loading-overlay fade-in';
                    overlay.innerHTML = `
                        <div class="glass" style="width: 300px; padding: 2rem; border-radius: 20px; display:flex; flex-direction:column; align-items:center; background: var(--glass-bg);">
                            <div class="skeleton-circle" style="width: 60px; height: 60px; margin-bottom: 1rem;"></div>
                            <div class="skeleton-text" style="width: 80%;"></div>
                            <div class="skeleton-text" style="width: 60%;"></div>
                            <div class="skeleton-text" style="width: 90%; height: 100px; margin-top: 1rem; border-radius: 12px;"></div>
                            <p class="text-sm" style="margin-top: 1rem; color: var(--text-muted);">Mempersiapkan Dasbor...</p>
                        </div>
                    `;
                    document.body.appendChild(overlay);

                    // Redirect
                    setTimeout(() => {
                        window.location.href = user.redirectUrl;
                    }, 1500);
                }, 800);
            } else {
                // Gagal login
                if (window.showToast) {
                    showToast("ID atau MPIN salah. Silakan coba lagi.", "error");
                }
                
                // Reset UI
                submitBtn.disabled = false;
                btnText.classList.remove('hidden');
                spinner.classList.add('hidden');
                mpinInput.value = '';
                mpinInput.focus();
            }
        }, 1200);
    });
});
